
Just in case you want to use Maven, you'll need these packages:

org.xerial:sqlite-jdbc
javax.persistence:javax.persistence-api
org.eclipse.persistence:eclipselink